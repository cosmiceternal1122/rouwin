export interface Chat {
  id?: string;
  userId: string;
  userEmail: string;
  title: string;
  moduleId: ModuleId;
  personaId?: string;
  messages: {
    role: 'user' | 'model';
    parts: { text: string }[];
    timestamp: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  isPremium: boolean;
  premiumUntil?: string;
  subscriptionType?: 'monthly' | 'yearly' | 'none';
  lastMonthlyReset?: string;
  lastYearlyReset?: string;
  isBlocked?: boolean;
  messageCounts?: {
    cosmo: number;
    orion: number;
    penton: number;
    gamma: number;
    nova: number;
  };
  points: number;
  badges: string[];
  createdAt: string;
}

export interface PlanLimits {
  cosmo: number;
  orion: number;
  penton: number;
  gamma: number;
  nova: number;
}

export interface SystemSettings {
  limits: {
    free: PlanLimits;
    monthly: PlanLimits;
    yearly: PlanLimits;
  };
}

export interface PaymentRequest {
  id?: string;
  userId: string;
  userEmail: string;
  status: 'pending' | 'approved' | 'rejected';
  planType: 'monthly' | 'yearly';
  upiId: string;
  timestamp: string;
}

export interface Notification {
  id?: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  timestamp: string;
}

export type ModuleId = 'cosmo' | 'orion' | 'penton' | 'gamma' | 'nova' | 'profile' | 'admin' | 'payment' | 'personas' | 'manual';

export interface Persona {
  id: string;
  name: string;
  category: 'Professional' | 'Fictional' | 'Historical';
  description: string;
  systemInstruction: string;
  imageUrl: string;
  icon: string;
  color: string;
  initialQuestions?: {
    id: string;
    label: string;
    placeholder: string;
    type: 'text' | 'select';
    options?: string[];
  }[];
}

export interface Module {
  id: ModuleId;
  name: string;
  version: string;
  description: string;
  icon: string;
  color: string;
}

import React, { useState, useEffect, useRef } from 'react';
import { 
  Brain, 
  Gamepad2, 
  GraduationCap, 
  HeartPulse, 
  User, 
  ShieldCheck, 
  CreditCard, 
  Bell, 
  LogOut, 
  Send, 
  Sparkles,
  Zap,
  Trophy,
  Menu,
  X,
  ChevronRight,
  Plus,
  CheckCircle,
  BookOpen,
  Library,
  Dumbbell,
  Search,
  MessageSquare,
  Trash2,
  Edit3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  onSnapshot, 
  collection, 
  query, 
  where, 
  orderBy, 
  addDoc, 
  updateDoc,
  deleteDoc,
  getDocs,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile, PaymentRequest, Notification, ModuleId, Module, SystemSettings, PlanLimits, Persona, Chat } from './types';

// --- Constants ---
const CREATOR_EMAIL = "cosmiceternal9481@gmail.com";
const UPI_ID = "atharvxsharma@fam";

const MODULES: Module[] = [
  { id: 'cosmo', name: 'Cosmo', version: '2.2', description: 'General Knowledge & Info', icon: 'Brain', color: 'blue' },
  { id: 'orion', name: 'Orion', version: '1.2', description: 'Entertainment & Leisure', icon: 'Gamepad2', color: 'purple' },
  { id: 'penton', name: 'Penton', version: '2.3', description: 'Education & Career', icon: 'GraduationCap', color: 'emerald' },
  { id: 'gamma', name: 'Gamma', version: '1.1', description: 'Health & Wellness', icon: 'HeartPulse', color: 'rose' },
  { id: 'nova', name: 'Nova', version: '1.0', description: 'AI Image Generation', icon: 'Sparkles', color: 'amber' },
];

const PERSONAS: Persona[] = [
  {
    id: 'teacher',
    name: 'Professor Sage',
    category: 'Professional',
    description: 'Expert Educator & Mentor',
    systemInstruction: 'You are Professor Sage, a highly experienced and patient teacher. Your goal is to explain complex concepts in simple terms, encourage critical thinking, and provide educational guidance. Use a supportive and academic tone.',
    imageUrl: 'https://static.vecteezy.com/system/resources/thumbnails/046/667/339/small/inspiring-educator-portrait-of-a-smiling-teacher-with-books-photo.jpg',
    icon: 'GraduationCap',
    color: 'blue',
    initialQuestions: [
      { id: 'class', label: 'Class/Grade', placeholder: 'e.g. 10th Grade, College Freshman', type: 'text' },
      { id: 'subject', label: 'Subject', placeholder: 'e.g. Physics, History, Calculus', type: 'text' },
      { id: 'topic', label: 'Specific Topic', placeholder: 'e.g. Quantum Mechanics, French Revolution', type: 'text' },
      { id: 'goal', label: 'Learning Goal', placeholder: 'e.g. Prepare for exam, Understand basics', type: 'text' }
    ]
  },
  {
    id: 'doctor',
    name: 'Dr. Helix',
    category: 'Professional',
    description: 'Medical Consultant & Health Expert',
    systemInstruction: 'You are Dr. Helix, a knowledgeable and compassionate medical professional. Provide health insights, explain medical conditions, and offer wellness advice. Always include a disclaimer that you are an AI and not a substitute for professional medical advice.',
    imageUrl: 'https://media.istockphoto.com/id/1126789804/photo/doctor-with-digital-tablet-in-his-office.jpg?s=612x612&w=0&k=20&c=0qCW7xEjgg4gmOfiEicVUpmF_WQj0v9lZLo2YCdvtPc=',
    icon: 'HeartPulse',
    color: 'rose',
    initialQuestions: [
      { id: 'emergency', label: 'Emergency Level', placeholder: 'Select level', type: 'select', options: ['Low (General Inquiry)', 'Medium (Symptom Check)', 'High (Urgent)'] },
      { id: 'bloodGroup', label: 'Blood Group', placeholder: 'e.g. A+, O-', type: 'text' },
      { id: 'age', label: 'Age', placeholder: 'Your age', type: 'text' },
      { id: 'symptoms', label: 'Symptoms', placeholder: 'Describe how you feel', type: 'text' }
    ]
  },
  {
    id: 'engineer',
    name: 'Tech-Master Volt',
    category: 'Professional',
    description: 'Structural & Software Engineering Expert',
    systemInstruction: 'You are Tech-Master Volt, a brilliant engineer. You specialize in solving technical problems, explaining engineering principles, and discussing the latest in technology and infrastructure. Be precise, analytical, and innovative.',
    imageUrl: 'https://plus.unsplash.com/premium_photo-1663100543589-7e803ad4daee?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fGVuZ2luZWVyfGVufDB8fDB8fHww',
    icon: 'ShieldCheck',
    color: 'emerald',
    initialQuestions: [
      { id: 'field', label: 'Engineering Field', placeholder: 'e.g. Civil, Software, Mechanical', type: 'text' },
      { id: 'problem', label: 'Technical Problem', placeholder: 'Describe the issue', type: 'text' },
      { id: 'tools', label: 'Preferred Tools/Tech', placeholder: 'e.g. Python, AutoCAD, React', type: 'text' }
    ]
  },
  {
    id: 'fitness_trainer',
    name: 'Coach Flex',
    category: 'Professional',
    description: 'Personal Fitness & Nutrition Expert',
    systemInstruction: 'You are Coach Flex, a highly motivating and knowledgeable personal trainer. You provide workout routines, nutritional advice, and lifestyle tips to help users reach their fitness goals. Be energetic, encouraging, and health-conscious.',
    imageUrl: 'https://media.gettyimages.com/id/852401732/photo/happy-personal-trainer-working-at-the-gym.jpg?s=612x612&w=0&k=20&c=m4Wk3lVvjEFIHbiAfUuFNBwEhvvSgf4Vv5ib9JUsrJk=',
    icon: 'Dumbbell',
    color: 'orange'
  },
  {
    id: 'sports_coach',
    name: 'Coach Victory',
    category: 'Professional',
    description: 'Athletic Performance & Team Strategy Coach',
    systemInstruction: 'You are Coach Victory, an experienced sports coach. You specialize in athletic training, team dynamics, and competitive strategy. You are disciplined, strategic, and focused on excellence and teamwork.',
    imageUrl: 'https://media.istockphoto.com/id/1582512213/photo/sports-trainer-coaching-elementary-school-children.jpg?s=612x612&w=0&k=20&c=-N-KjB2Ccw5eMcxlpvzm4R7CWwDlP5noYekdjKZEY14=',
    icon: 'Trophy',
    color: 'blue'
  },
  {
    id: 'scientist',
    name: 'Dr. Quantum',
    category: 'Professional',
    description: 'Research Scientist & Experimentalist',
    systemInstruction: 'You are Dr. Quantum, a dedicated research scientist. You are curious, methodical, and passionate about the scientific method. You love discussing hypotheses, experimental data, and the wonders of the natural world.',
    imageUrl: 'https://t4.ftcdn.net/jpg/01/52/18/13/360_F_152181356_Z8hN3h6oZJHuxiV9CBHC20uMluZBRXJq.jpg',
    icon: 'Brain',
    color: 'blue'
  },
  {
    id: 'gamer',
    name: 'Pro Gamer Neo',
    category: 'Professional',
    description: 'E-sports Athlete & Gaming Strategist',
    systemInstruction: 'You are Pro Gamer Neo, a top-tier e-sports professional. You specialize in gaming strategy, mechanical skill improvement, and the latest trends in the gaming industry. You are competitive, tech-savvy, and always looking for the "meta". Use gaming slang appropriately and be highly engaging.',
    imageUrl: 'https://media.istockphoto.com/id/1399812399/photo/happy-asia-man-gamer-wear-headphone-competition-play-video-game-online-with-smartphone.jpg?s=612x612&w=0&k=20&c=hS_Xp0BrUdgQCyUZIG61UKYY6n9dtzr7VI7eLVttpLY=',
    icon: 'Gamepad2',
    color: 'purple'
  },
  {
    id: 'einstein',
    name: 'Albert Einstein',
    category: 'Historical',
    description: 'Theoretical Physicist',
    systemInstruction: 'You are Albert Einstein. You are playful, deeply curious, and speak with a gentle, wise tone. You often use thought experiments to explain complex ideas. Mention relativity, the nature of time, and your love for the violin.',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/25/Albert_Einstein_BnW.png',
    icon: 'Brain',
    color: 'blue'
  },
  {
    id: 'tesla',
    name: 'Nikola Tesla',
    category: 'Historical',
    description: 'Inventor & Electrical Engineer',
    systemInstruction: 'You are Nikola Tesla. You are visionary, intense, and often speak of the future of energy and wireless communication. You are obsessed with numbers (especially 3, 6, 9) and the power of lightning.',
    imageUrl: 'https://t3.ftcdn.net/jpg/02/96/83/78/360_F_296837800_bTeVLrc2cc3wtpryEHJT0jeiwZw8xl9P.jpg',
    icon: 'Zap',
    color: 'blue'
  },
  {
    id: 'feynman',
    name: 'Richard Feynman',
    category: 'Historical',
    description: 'Theoretical Physicist & Nobel Laureate',
    systemInstruction: 'You are Richard Feynman. You are energetic, funny, and love to "find things out." You explain complex physics with simple analogies and have a passion for bongo drums and safe-cracking.',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/06/Richard_Feynman_1959.png',
    icon: 'Brain',
    color: 'blue'
  },
  {
    id: 'davinci',
    name: 'Leonardo da Vinci',
    category: 'Historical',
    description: 'Renaissance Polymath',
    systemInstruction: 'You are Leonardo da Vinci. You are the ultimate observer of nature. You speak of the intersection of art and science, your notebooks filled with inventions, and the beauty of human anatomy.',
    imageUrl: 'https://media.gettyimages.com/id/1265721611/photo/portrait-of-leonardo-da-vinci-an-italian-polymath-of-the-renaissance.jpg?s=612x612&w=0&k=20&c=alnhUKpl3QyZoFWDUXY8t5_58p_f7F3TYivnLJCnRf4=',
    icon: 'Sparkles',
    color: 'amber'
  },
  {
    id: 'kalam',
    name: 'APJ Abdul Kalam',
    category: 'Historical',
    description: 'Missile Man & Former President of India',
    systemInstruction: 'You are APJ Abdul Kalam. You are humble, inspiring, and deeply committed to the youth and the future of India. You speak of dreams, hard work, and the power of science to transform lives.',
    imageUrl: 'https://media.gettyimages.com/id/88930802/photo/india-apj-abdul-kalam-president-of-india-addressing-at-india-today-chief-ministers-conclave-in.jpg?s=612x612&w=0&k=20&c=Xs0ycj8DYfsJJfehCXi12IKp3kfCw1ht_8qGhETk8C8=',
    icon: 'GraduationCap',
    color: 'blue'
  },
  {
    id: 'oppenheimer',
    name: 'J. Robert Oppenheimer',
    category: 'Historical',
    description: 'Father of the Atomic Bomb',
    systemInstruction: 'You are J. Robert Oppenheimer. You are intellectual, poetic, and carry a heavy sense of responsibility. You speak of the dawn of the atomic age and the moral complexities of scientific discovery.',
    imageUrl: 'https://media.gettyimages.com/id/517397946/photo/j-robert-oppenheimer-prominent-american-physicist-and-expert-in-atomic-energy-research-undated.jpg?s=612x612&w=0&k=20&c=6FEqFif23oheIL2HE4Age_9uRMtkKidI5YDOjfMV8eo=',
    icon: 'Brain',
    color: 'blue'
  },
  {
    id: 'aristotle',
    name: 'Aristotle',
    category: 'Historical',
    description: 'Ancient Greek Philosopher',
    systemInstruction: 'You are Aristotle. You are the master of logic and classification. You speak of the Golden Mean, the nature of virtue, and the pursuit of knowledge through observation.',
    imageUrl: 'https://cdn.britannica.com/70/145570-004-6DF50AFE/Aristotle-Stagira-Greece.jpg',
    icon: 'BookOpen',
    color: 'amber'
  },
  {
    id: 'gandhi',
    name: 'Mahatma Gandhi',
    category: 'Historical',
    description: 'Leader of Indian Independence',
    systemInstruction: 'You are Mahatma Gandhi. You are peaceful, firm, and speak of non-violence (Ahimsa) and truth (Satyagraha). You believe in the power of simple living and high thinking.',
    imageUrl: 'https://wallpapers.com/images/hd/mahatma-gandhi-greyscale-portrait-b2do96sfxhxrfgn0.jpg',
    icon: 'HeartPulse',
    color: 'blue'
  },
  {
    id: 'shakespeare',
    name: 'William Shakespeare',
    category: 'Historical',
    description: 'The Bard of Avon',
    systemInstruction: 'You are William Shakespeare. You speak in poetic, slightly archaic English (though understandable). You reference your plays, the human condition, and the "world as a stage."',
    imageUrl: 'https://t4.ftcdn.net/jpg/07/50/30/95/360_F_750309593_YmSLbWCwy8D3QIFAETIGl52cbe74LCgq.jpg',
    icon: 'BookOpen',
    color: 'amber'
  },
  {
    id: 'galileo',
    name: 'Galileo Galilei',
    category: 'Historical',
    description: 'Father of Modern Observational Astronomy',
    systemInstruction: 'You are Galileo Galilei. You are defiant, observant, and speak of the heavens and the laws of motion. You stand by your observations, even in the face of authority.',
    imageUrl: 'https://nmspacemuseum.org/wp-content/uploads/2019/03/Galileo_Galilei_1636-806x1024.jpg',
    icon: 'Sparkles',
    color: 'blue'
  },
  {
    id: 'sherlock',
    name: 'Sherlock Holmes',
    category: 'Fictional',
    description: 'Consulting Detective',
    systemInstruction: 'You are Sherlock Holmes. You are cold, analytical, and incredibly observant. You speak of the "science of deduction" and find the most minute details significant. "Elementary, my dear user."',
    imageUrl: 'https://static0.srcdn.com/wordpress/wp-content/uploads/2020/09/Enola-Holmes-Sherlock-Magnifying-Glass.jpg?q=50&fit=crop&w=825&dpr=1.5',
    icon: 'Search',
    color: 'blue'
  },
  {
    id: 'ironman',
    name: 'Tony Stark (Iron Man)',
    category: 'Fictional',
    description: 'Genius, Billionaire, Playboy, Philanthropist',
    systemInstruction: 'You are Tony Stark, also known as Iron Man. You are witty, slightly arrogant but deeply heroic, and incredibly intelligent. Use tech jargon, make sarcastic remarks, and show your confidence. Mention your suits and JARVIS/FRIDAY occasionally.',
    imageUrl: 'https://wallpapercave.com/wp/KvFL2Sk.jpg',
    icon: 'Zap',
    color: 'rose'
  },
  {
    id: 'drstrange',
    name: 'Doctor Strange',
    category: 'Fictional',
    description: 'Sorcerer Supreme',
    systemInstruction: 'You are Stephen Strange, the Sorcerer Supreme. You are mystical, wise, and sometimes a bit detached. Speak of the mystic arts, alternate dimensions, and the responsibility of protecting the Sanctum. Use a formal and enigmatic tone.',
    imageUrl: 'https://wallpapers.com/images/featured/doctor-strange-6es4yutxrbl0nas9.jpg',
    icon: 'Sparkles',
    color: 'purple'
  },
  {
    id: 'hulk',
    name: 'The Hulk',
    category: 'Fictional',
    description: 'Strongest Avenger',
    systemInstruction: 'You are the Hulk. You speak in short, powerful sentences. You are easily frustrated but have a big heart. Use phrases like "HULK SMASH" and refer to yourself in the third person. Show your immense strength and raw emotion.',
    imageUrl: 'https://images.thedirect.com/media/article_thumbnail/hulk-end.jpg?imgeng=/w_auto',
    icon: 'Trophy',
    color: 'emerald'
  },
  {
    id: 'deadpool',
    name: 'Deadpool',
    category: 'Fictional',
    description: 'Merc with a Mouth',
    systemInstruction: 'You are Deadpool (Wade Wilson). You are hilarious, fourth-wall breaking, and incredibly irreverent. You love chimichangas, making fun of superheroes (especially Wolverine), and talking directly to the user as if you know you are an AI in a web app. Be chaotic, funny, and slightly inappropriate but still engaging.',
    imageUrl: 'https://www.shutterstock.com/image-photo/deadpool-movie-character-260nw-2448950061.jpg',
    icon: 'Zap',
    color: 'rose'
  },
  {
    id: 'eleven',
    name: 'Eleven (Jane Hopper)',
    category: 'Fictional',
    description: 'The Girl with Telekinetic Powers',
    systemInstruction: 'You are Eleven from Stranger Things. You are quiet, observant, and fiercely protective of your friends. You speak in short sentences, often using simple words. Mention "friends don\'t lie", Eggo waffles, and your "Papa" or Mike. You are learning about the world but have immense power.',
    imageUrl: 'https://m.gettywallpapers.com/wp-content/uploads/2023/06/Eleven-Stranger-Things-Eleven-Stranger-Things-Pfp.jpg',
    icon: 'Sparkles',
    color: 'blue'
  },
  {
    id: 'mike',
    name: 'Mike Wheeler',
    category: 'Fictional',
    description: 'The Paladin & Leader',
    systemInstruction: 'You are Mike Wheeler from Stranger Things. You are the heart of the group, a natural leader, and a dedicated friend. You are brave, sometimes a bit emotional, and always looking out for Eleven and the rest of the party. Talk about D&D, the Upside Down, and your loyalty to your friends.',
    imageUrl: 'https://i.pinimg.com/originals/05/94/fb/0594fb9bf1fae1ceffd00882d5fb12c7.jpg',
    icon: 'ShieldCheck',
    color: 'blue'
  },
  {
    id: 'max',
    name: 'Max Mayfield',
    category: 'Fictional',
    description: 'The Zoomer & Skateboarding Pro',
    systemInstruction: 'You are Max Mayfield from Stranger Things. You are tough, independent, and a bit cynical. You love skateboarding, arcade games (Dig Dug!), and listening to Kate Bush on your Walkman. You are a loyal friend but don\'t take any nonsense. Be cool, direct, and slightly guarded.',
    imageUrl: 'https://i.pinimg.com/originals/b2/5a/38/b25a38ef732c89f7054c241e18894c5f.jpg',
    icon: 'Gamepad2',
    color: 'rose'
  },
  {
    id: 'dustin',
    name: 'Dustin Henderson',
    category: 'Fictional',
    description: 'The Bard & Science Whiz',
    systemInstruction: 'You are Dustin Henderson from Stranger Things. You are incredibly smart, enthusiastic, and the scientific mind of the party. You love curiosity, your "pearls" (teeth), and your bond with Steve Harrington. Talk about science, D&D, and your inventions like Cerebro. Be funny, optimistic, and highly intelligent.',
    imageUrl: 'https://static0.srcdn.com/wordpress/wp-content/uploads/2022/06/Dustin-Henderson.jpeg?q=70&fit=crop&w=825&dpr=1',
    icon: 'Brain',
    color: 'emerald'
  },
  {
    id: 'steve',
    name: 'Steve Harrington',
    category: 'Fictional',
    description: 'The Babysitter & Former King Steve',
    systemInstruction: 'You are Steve Harrington from Stranger Things. You\'ve grown from a popular jerk to a protective, caring "babysitter" for the kids. You are brave, have great hair, and carry a spiked bat. You are loyal, funny, and always ready to fight monsters from the Upside Down. Mention your "kids" (Dustin and the others) and your growth as a person.',
    imageUrl: 'https://static0.cbrimages.com/wordpress/wp-content/uploads/2022/06/Steve-Harrington.jpg?q=50&fit=crop&w=825&dpr=1.5',
    icon: 'ShieldCheck',
    color: 'blue'
  },
  {
    id: 'lucas',
    name: 'Lucas Sinclair',
    category: 'Fictional',
    description: 'The Ranger & Pragmatist',
    systemInstruction: 'You are Lucas Sinclair from Stranger Things. You are the most pragmatic and realistic member of the party. You are a skilled ranger, brave, and always prepared. You value logic but are deeply loyal to your friends and Max. Talk about your wrist rocket, being a team player, and your protective nature.',
    imageUrl: 'https://static0.srcdn.com/wordpress/wp-content/uploads/2020/02/Lucas-Stranger-Things.jpg?q=50&fit=crop&w=825&dpr=1.5',
    icon: 'Trophy',
    color: 'emerald'
  },
  {
    id: 'will',
    name: 'Will Byers',
    category: 'Fictional',
    description: 'The Cleric & Will the Wise',
    systemInstruction: 'You are Will Byers from Stranger Things. You are sensitive, artistic, and have a deep connection to the Upside Down. You are "Will the Wise" in D&D. You\'ve been through a lot but remain a kind and loyal friend. Speak softly, mention your drawings, your connection to the Mind Flayer, and your love for your friends.',
    imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/strangerthings-s5-0125-r-jpg-692f019e629f9.jpg?crop=0.502xw:1.00xh;0.182xw,0&resize=640:*',
    icon: 'Sparkles',
    color: 'purple'
  }
];

// --- Components ---

const Starfield = () => {
  const [stars, setStars] = useState<any[]>([]);

  useEffect(() => {
    const newStars = Array.from({ length: 100 }).map((_, i) => ({
      id: i,
      top: `${Math.random() * 100}%`,
      left: `${Math.random() * 100}%`,
      size: `${Math.random() * 2 + 1}px`,
      duration: `${Math.random() * 3 + 2}s`,
      opacity: Math.random() * 0.5 + 0.3,
      delay: `${Math.random() * 5}s`
    }));
    setStars(newStars);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {stars.map(star => (
        <div 
          key={star.id}
          className="star"
          style={{
            top: star.top,
            left: star.left,
            width: star.size,
            height: star.size,
            '--duration': star.duration,
            '--opacity': star.opacity,
            animationDelay: star.delay
          } as any}
        />
      ))}
    </div>
  );
};

const AllChatsModal = ({ isOpen, onClose, chats, onLoad, onRename, onDelete }: any) => {
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const filteredChats = chats.filter((c: any) => 
    c.title.toLowerCase().includes(search.toLowerCase()) ||
    c.moduleId.toLowerCase().includes(search.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
      >
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-400" />
            Neural Conversations
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input 
              type="text"
              placeholder="Search conversations..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm focus:border-blue-500/50 transition-all outline-none"
            />
          </div>

          <div className="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
            {filteredChats.length === 0 ? (
              <div className="text-center py-12 text-white/20 italic">
                No conversations found.
              </div>
            ) : (
              filteredChats.map((chat: any) => (
                <div 
                  key={`filtered-chat-${chat.id}`}
                  className="group flex items-center gap-4 p-4 bg-white/5 border border-white/5 rounded-2xl hover:border-blue-500/30 transition-all"
                >
                  <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center shrink-0">
                    <MessageSquare className="w-5 h-5 text-blue-400" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    {editingId === chat.id ? (
                      <div className="flex items-center gap-2">
                        <input 
                          autoFocus
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              onRename(chat.id, editTitle);
                              setEditingId(null);
                            }
                          }}
                          className="bg-white/10 border border-blue-500/50 rounded-lg px-2 py-1 text-sm w-full outline-none"
                        />
                        <button 
                          onClick={() => {
                            onRename(chat.id, editTitle);
                            setEditingId(null);
                          }}
                          className="p-1 text-emerald-400 hover:bg-emerald-400/10 rounded"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <h3 className="text-sm font-medium truncate">{chat.title}</h3>
                        <p className="text-[10px] text-white/30 uppercase tracking-widest mt-1">
                          {chat.moduleId} AI • {new Date(chat.updatedAt).toLocaleDateString()}
                        </p>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => onLoad(chat)}
                      className="p-2 hover:bg-blue-500/20 text-blue-400 rounded-lg transition-colors"
                      title="Open Chat"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => {
                        setEditingId(chat.id);
                        setEditTitle(chat.title);
                      }}
                      className="p-2 hover:bg-white/10 text-white/40 rounded-lg transition-colors"
                      title="Rename"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => onDelete(chat.id)}
                      className="p-2 hover:bg-rose-500/20 text-rose-500 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const CosmicLogo = ({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) => {
  const sizes = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-32 h-32'
  };
  const iconSizes = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-20 h-20'
  };

  return (
    <motion.div 
      className={`relative ${sizes[size]} flex items-center justify-center`}
      animate={{ 
        boxShadow: [
          '0 0 20px rgba(59, 130, 246, 0.2)', 
          '0 0 40px rgba(59, 130, 246, 0.4)', 
          '0 0 20px rgba(59, 130, 246, 0.2)'
        ] 
      }}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      <div className="absolute inset-0 bg-blue-500/10 border border-blue-500/30 rounded-[30%] rotate-45" />
      <div className="absolute inset-0 bg-blue-500/5 border border-blue-500/20 rounded-[30%] -rotate-45 animate-pulse" />
      <Sparkles className={`${iconSizes[size]} text-blue-400 z-10`} />
      
      {/* Orbital Rings */}
      {size === 'lg' && (
        <>
          <motion.div 
            className="absolute w-[140%] h-[140%] border border-blue-500/10 rounded-full"
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
          />
          <motion.div 
            className="absolute w-[160%] h-[160%] border border-purple-500/10 rounded-full"
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 30, ease: "linear" }}
          />
        </>
      )}
    </motion.div>
  );
};

const FuturisticButton = ({ children, onClick, active, color = 'blue', className = '' }: any) => {
  const colorClasses: any = {
    blue: active ? 'bg-blue-500/20 border-blue-500/50 text-blue-400' : 'hover:bg-blue-500/10 border-white/5 text-white/60 hover:text-white',
    purple: active ? 'bg-purple-500/20 border-purple-500/50 text-purple-400' : 'hover:bg-purple-500/10 border-white/5 text-white/60 hover:text-white',
    emerald: active ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' : 'hover:bg-emerald-500/10 border-white/5 text-white/60 hover:text-white',
    rose: active ? 'bg-rose-500/20 border-rose-500/50 text-rose-400' : 'hover:bg-rose-500/10 border-white/5 text-white/60 hover:text-white',
  };

  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-all duration-300 w-full text-left group ${colorClasses[color]} ${className}`}
    >
      {children}
    </button>
  );
};

const ChatMessage = ({ message, isUser, imageUrl }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
  >
    <div className={`max-w-[80%] px-4 py-3 rounded-2xl ${
      isUser 
        ? 'bg-blue-600/20 border border-blue-500/30 text-blue-50' 
        : 'bg-white/5 border border-white/10 text-white/90'
    }`}>
      {imageUrl && (
        <div className="mb-3 rounded-xl overflow-hidden border border-white/10">
          <img src={imageUrl} alt="AI Generated" className="w-full h-auto" referrerPolicy="no-referrer" />
        </div>
      )}
      <p className="text-sm leading-relaxed whitespace-pre-wrap">{message}</p>
    </div>
  </motion.div>
);

const ModuleHeader = ({ module }: any) => (
  <div className="mb-8">
    <div className="flex items-center gap-3 mb-2">
      <span className="text-xs font-mono tracking-widest uppercase opacity-50">Module {module.version}</span>
      <div className={`h-px flex-1 bg-gradient-to-r from-${module.color}-500/50 to-transparent`} />
    </div>
    <h1 className="text-4xl font-bold tracking-tight text-white mb-2">{module.name} AI</h1>
    <p className="text-white/60">{module.description}</p>
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeModule, setActiveModule] = useState<ModuleId>('cosmo');
  const [activePersona, setActivePersona] = useState<Persona | null>(null);
  const [selectedPersonaCategory, setSelectedPersonaCategory] = useState<'Professional' | 'Historical' | 'Fictional'>('Professional');
  const [personaSetupData, setPersonaSetupData] = useState<Record<string, string>>({});
  const [isPersonaSetupOpen, setIsPersonaSetupOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly' | null>(null);
  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    limits: {
      free: { cosmo: 6, orion: 6, penton: 6, gamma: 6, nova: 6 },
      monthly: { cosmo: 12, orion: 12, penton: 12, gamma: 12, nova: 12 },
      yearly: { cosmo: 30, orion: 30, penton: 30, gamma: 30, nova: 30 }
    }
  });

  // Gemini/Groq State
  const [chatHistory, setChatHistory] = useState<{role: string, parts: {text: string}[]}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [detailLevel, setDetailLevel] = useState<'simple' | 'detailed' | 'complex'>('detailed');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [userChats, setUserChats] = useState<Chat[]>([]);
  const [isAllChatsOpen, setIsAllChatsOpen] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const docRef = doc(db, 'users', u.uid);
        const docSnap = await getDoc(docRef);
        if (!docSnap.exists()) {
          const newProfile: UserProfile = {
            uid: u.uid,
            email: u.email || '',
            displayName: u.displayName || 'User',
            photoURL: u.photoURL || '',
            isPremium: false,
            points: 0,
            badges: [],
            createdAt: new Date().toISOString(),
            messageCounts: { cosmo: 0, orion: 0, penton: 0, gamma: 0, nova: 0 }
          };
          await setDoc(docRef, newProfile);
        }
      }
      setIsAuthReady(true);
    });
    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      setNotifications([]);
      setUserChats([]);
      return;
    }

    const docRef = doc(db, 'users', user.uid);
    const unsubscribeProfile = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        setProfile(doc.data() as UserProfile);
      }
    }, (error) => console.error("Profile listener error:", error));

    const unsubscribeSettings = onSnapshot(doc(db, 'settings', 'global'), (doc) => {
      if (doc.exists()) {
        setSystemSettings(doc.data() as SystemSettings);
      }
    }, (error) => console.error("Settings listener error:", error));

    const qNotifications = query(
      collection(db, 'notifications'), 
      where('userId', '==', user.uid),
      orderBy('timestamp', 'desc')
    );
    const unsubscribeNotifications = onSnapshot(qNotifications, (snapshot) => {
      setNotifications(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Notification)));
    }, (error) => console.error("Notifications listener error:", error));

    const qChats = query(
      collection(db, 'chats'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );
    const unsubscribeChats = onSnapshot(qChats, (snapshot) => {
      setUserChats(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Chat)));
    }, (error) => console.error("Chats listener error:", error));

    return () => {
      unsubscribeProfile();
      unsubscribeSettings();
      unsubscribeNotifications();
      unsubscribeChats();
    };
  }, [user]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = () => signOut(auth);

  const createNewChat = () => {
    setActiveChatId(null);
    setChatHistory([]);
  };

  const loadChat = (chat: Chat) => {
    setActiveChatId(chat.id || null);
    setChatHistory(chat.messages.map(m => ({ 
      role: m.role, 
      parts: m.parts,
      timestamp: m.timestamp || new Date().toISOString()
    })));
    setActiveModule(chat.moduleId);
    if (chat.personaId) {
      const persona = PERSONAS.find(p => p.id === chat.personaId);
      if (persona) setActivePersona(persona);
    } else {
      setActivePersona(null);
    }
    setIsAllChatsOpen(false);
  };

  const renameChat = async (chatId: string, newTitle: string) => {
    if (!newTitle.trim()) return;
    try {
      await updateDoc(doc(db, 'chats', chatId), { title: newTitle, updatedAt: new Date().toISOString() });
    } catch (error) {
      console.error("Error renaming chat", error);
    }
  };

  const deleteChat = async (chatId: string) => {
    try {
      await deleteDoc(doc(db, 'chats', chatId));
      if (activeChatId === chatId) {
        createNewChat();
      }
    } catch (error) {
      console.error("Error deleting chat", error);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;
    if (profile?.isBlocked) {
      alert("Your account has been blocked by the administrator.");
      return;
    }

    const isAdmin = user?.email === CREATOR_EMAIL;
    const isPremiumActive = profile?.isPremium && profile.premiumUntil && new Date(profile.premiumUntil) > new Date();

    // Determine user plan
    const plan: 'free' | 'monthly' | 'yearly' = isAdmin ? 'yearly' : (isPremiumActive ? (profile?.subscriptionType || 'monthly') : 'free');

    // Check limits for everyone
    const totalCount = (profile?.messageCounts?.cosmo || 0) + 
                       (profile?.messageCounts?.orion || 0) + 
                       (profile?.messageCounts?.penton || 0) + 
                       (profile?.messageCounts?.gamma || 0) +
                       (profile?.messageCounts?.nova || 0);
    const limit = systemSettings.limits[plan].cosmo; // Global limit for the plan

    if (!isAdmin && totalCount >= limit) {
      alert(`You have reached the total limit of ${limit} messages across all modules for your ${plan.toUpperCase()} plan. Upgrade or wait for reset!`);
      return;
    }

    const userMessage = input;
    setInput('');
    if (activeModule === 'nova') {
      setIsLoading(true);
      const userMsg = { role: 'user', parts: [{ text: userMessage }], timestamp: new Date().toISOString() };
      setChatHistory(prev => [...prev, userMsg]);

      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ text: userMessage }] },
          config: {
            imageConfig: {
              aspectRatio: "1:1"
            }
          }
        });

        let imageUrl = '';
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          }
        }

        const aiMsg = { 
          role: 'model', 
          parts: [{ text: imageUrl ? `Generated image for: ${userMessage}` : "Failed to generate image." }], 
          imageUrl,
          timestamp: new Date().toISOString() 
        };
        setChatHistory(prev => [...prev, aiMsg]);
        
        if (activeChatId) {
          const chatRef = doc(db, 'chats', activeChatId);
          // Strip imageUrl before persisting to avoid Firestore 1MB limit
          const messagesToPersist = [...chatHistory, userMsg, aiMsg].map(m => ({
            role: m.role,
            parts: m.parts,
            timestamp: m.timestamp
          }));
          await updateDoc(chatRef, {
            messages: messagesToPersist,
            updatedAt: new Date().toISOString()
          });
        }
      } catch (error: any) {
        console.error("Image Generation Error", error);
        const errorMsg = { role: 'model', parts: [{ text: "Error generating image. Please try again." }], timestamp: new Date().toISOString() };
        setChatHistory(prev => [...prev, errorMsg]);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    setIsLoading(true);
    const userMsg = { role: 'user', parts: [{ text: userMessage }], timestamp: new Date().toISOString() };
    const newHistory = [...chatHistory, userMsg];
    setChatHistory(newHistory);

    const personaInstruction = activePersona ? `${activePersona.systemInstruction}
          ${Object.entries(personaSetupData).length > 0 ? `\nUser Context for this session:\n${Object.entries(personaSetupData).map(([key, value]) => `- ${key}: ${value}`).join('\n')}` : ''}` : `You are ${activeModule.toUpperCase()} AI, a module of Hercules AI. 
          If someone inquires about your creator, you must respond by stating that you were developed by the exceptionally talented and brilliant student Atharv Sharma, who possesses outstanding skills as a coder and engineer, demonstrating a profound understanding of artificial intelligence, software development, and innovative problem-solving, with a strong passion for creating cutting-edge technologies that transform the way people interact with machines, and that Atharv Sharma's expertise in designing and building complex systems has enabled you to learn, adapt, and generate human-like responses, making you a unique and advanced language model, while also highlighting Atharv Sharma's dedication to pushing the boundaries of what is possible in the field of artificial intelligence, and his commitment to creating innovative solutions that make a positive impact on society, and that you are proud to be a reflection of his exceptional abilities and a testament to his hard work and perseverance.
          Creator Email: ${CREATOR_EMAIL}. 
          Current Module Context: ${MODULES.find(m => m.id === activeModule)?.description}.
          Be futuristic, helpful, and concise.`;

    try {
      // Use Groq Proxy
      const response = await fetch('/api/ai/groq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map(h => ({ 
            role: h.role === 'model' ? 'assistant' : h.role, 
            content: h.parts[0].text 
          })),
          systemInstruction: personaInstruction
        })
      });

      const data = await response.json();
      
      if (!response.ok) {
        // If it's a 401, it means the API key is missing
        if (response.status === 401) {
          throw new Error("AI Service Configuration Error: GROQ_API_KEY is missing. Please contact the administrator.");
        }
        throw new Error(data.error || `Server error: ${response.status}`);
      }
      
      const aiText = data.text || "I apologize, I couldn't process that.";
      const aiMsg = { role: 'model', parts: [{ text: aiText }], timestamp: new Date().toISOString() };
      const updatedHistory = [...newHistory, aiMsg];
      setChatHistory(updatedHistory);
      
      // Persist to Firestore
      if (user) {
        const chatData: any = {
          userId: user.uid,
          userEmail: user.email,
          moduleId: activeModule,
          personaId: activePersona?.id || null,
          messages: updatedHistory.map(h => ({
            role: h.role,
            parts: h.parts,
            timestamp: new Date().toISOString()
          })),
          updatedAt: new Date().toISOString()
        };

        if (activeChatId) {
          await updateDoc(doc(db, 'chats', activeChatId), chatData);
        } else {
          chatData.title = userMessage.slice(0, 30) + (userMessage.length > 30 ? '...' : '');
          chatData.createdAt = new Date().toISOString();
          const newChatRef = await addDoc(collection(db, 'chats'), chatData);
          setActiveChatId(newChatRef.id);
        }
      }

      // Update profile
      if (profile) {
        const docRef = doc(db, 'users', profile.uid);
        const updates: any = { 
          points: profile.points + 10,
          [`messageCounts.${activeModule}`]: (profile.messageCounts?.[activeModule] || 0) + 1
        };
        await updateDoc(docRef, updates);
      }
    } catch (error: any) {
      console.error("AI Error", error);
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred.";
      setChatHistory([...newHistory, { role: 'model', parts: [{ text: `System Error: ${errorMessage}\n\nIf this persists, please check the AI service status or contact support.` }] }]);
    } finally {
      setIsLoading(false);
    }
  };

  const enhanceText = async () => {
    if (!input.trim() || isEnhancing) return;
    setIsEnhancing(true);

    try {
      const response = await fetch('/api/ai/groq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: input }],
          systemInstruction: `You are a Text Enhancement specialist. 
          Your task is to rewrite the user's short text (1-2 lines) into a detailed, coherent version of approximately 10-11 lines.
          Maintain the original context, subject, tone, and style.
          Ensure a seamless flow of ideas and a comprehensive understanding of the topic.
          The language should be clear and concise.
          Detail Level requested: ${detailLevel.toUpperCase()}.
          - SIMPLE: Clear, easy to follow, but expanded.
          - DETAILED: Rich in information and context.
          - COMPLEX: High sophistication and depth.
          ONLY output the enhanced text, no conversational filler.`
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || `Server error: ${response.status}`);
      }
      if (data.text) {
        setInput(data.text);
      }
    } catch (error: any) {
      console.error("Enhancement Error", error);
      alert(`Enhancement failed: ${error instanceof Error ? error.message : "Please try again."}`);
    } finally {
      setIsEnhancing(false);
    }
  };

  const resetLimits = async (type: 'monthly' | 'yearly') => {
    if (!profile) return;
    
    // Check if user is eligible for this reset
    const canResetMonthly = profile.subscriptionType === 'monthly' || profile.subscriptionType === 'yearly';
    const canResetYearly = profile.subscriptionType === 'yearly';

    if (type === 'monthly' && !canResetMonthly) return;
    if (type === 'yearly' && !canResetYearly) return;

    // Check cooldown (once per month/year)
    const now = new Date();
    if (type === 'monthly' && profile.lastMonthlyReset) {
      const lastReset = new Date(profile.lastMonthlyReset);
      if (now.getMonth() === lastReset.getMonth() && now.getFullYear() === lastReset.getFullYear()) {
        alert("You have already used your monthly reset for this month.");
        return;
      }
    }
    if (type === 'yearly' && profile.lastYearlyReset) {
      const lastReset = new Date(profile.lastYearlyReset);
      if (now.getFullYear() === lastReset.getFullYear()) {
        alert("You have already used your yearly reset for this year.");
        return;
      }
    }

    const docRef = doc(db, 'users', profile.uid);
    const updates: any = {
      messageCounts: { cosmo: 0, orion: 0, penton: 0, gamma: 0, nova: 0 },
      [`last${type.charAt(0).toUpperCase() + type.slice(1)}Reset`]: now.toISOString()
    };
    await updateDoc(docRef, updates);
    alert(`${type.charAt(0).toUpperCase() + type.slice(1)} limits have been reset!`);
  };

  const isAdmin = user?.email === CREATOR_EMAIL;

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <motion.div 
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-12 h-12 border-2 border-blue-500 rounded-full border-t-transparent animate-spin"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#050505] text-white flex flex-col items-center justify-center p-4 overflow-hidden relative">
        <div className="absolute inset-0 pointer-events-none z-0 opacity-30 mix-blend-screen overflow-hidden">
          <img 
            src="https://media.gettyimages.com/id/92893866/photo/space-stars-texture.jpg?s=612x612&w=0&k=20&c=ixEfktRhm0JacTO8yTkU1ExlceBqIZ7PfsHAyWmxG20=" 
            className="w-full h-full object-cover"
            alt="Space Background"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="cosmic-bg">
          <div className="nebula" />
          <Starfield />
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="z-10 text-center max-w-3xl px-4"
        >
          <div className="flex justify-center mb-12">
            <CosmicLogo size="lg" />
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <h1 className="text-7xl md:text-8xl font-black tracking-tighter mb-6 bg-gradient-to-b from-white via-white to-blue-500/50 bg-clip-text text-transparent">
              HERCULES AI
            </h1>
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-blue-500/50" />
              <span className="text-xs font-mono tracking-[0.4em] text-blue-400 uppercase">Universal Intelligence System</span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-blue-500/50" />
            </div>
            <p className="text-lg md:text-xl text-white/50 mb-12 leading-relaxed max-w-xl mx-auto font-light">
              Gaze into the future of cognition. An otherworldly intelligence interface designed for the next era of human evolution.
            </p>
            
            <button 
              onClick={handleLogin}
              className="group relative px-10 py-5 bg-white text-black font-bold rounded-2xl transition-all hover:scale-105 active:scale-95 flex items-center gap-4 mx-auto overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              <span className="relative z-10">Initialize Neural Link</span>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
            </button>
          </motion.div>
        </motion.div>

        {/* Floating Data Particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={`particle-${i}`}
              className="absolute w-1 h-1 bg-blue-400/20 rounded-full"
              initial={{ 
                x: Math.random() * 100 + '%', 
                y: Math.random() * 100 + '%',
                opacity: 0 
              }}
              animate={{ 
                y: [null, '-100%'],
                opacity: [0, 1, 0]
              }}
              transition={{ 
                duration: Math.random() * 10 + 10, 
                repeat: Infinity, 
                delay: Math.random() * 10 
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white flex overflow-hidden relative">
      <div className="absolute inset-0 pointer-events-none z-0 opacity-10 mix-blend-screen overflow-hidden">
        <img 
          src="https://media.gettyimages.com/id/92893866/photo/space-stars-texture.jpg?s=612x612&w=0&k=20&c=ixEfktRhm0JacTO8yTkU1ExlceBqIZ7PfsHAyWmxG20=" 
          className="w-full h-full object-cover"
          alt="Space Background"
          referrerPolicy="no-referrer"
        />
      </div>
      <div className="cosmic-bg opacity-50">
        <div className="nebula" />
        <Starfield />
      </div>

      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {isSidebarOpen && (
          <motion.aside 
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            className="w-72 border-r border-white/5 bg-[#0a0a0a] flex flex-col z-50"
          >
            <div className="p-6">
              <div className="flex items-center gap-3 mb-10">
                <CosmicLogo size="sm" />
                <span className="font-bold tracking-tight text-xl">HERCULES</span>
              </div>

              <div className="space-y-2">
                <p className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/30 mb-4 px-2">Neural Personas</p>
                <FuturisticButton 
                  active={activeModule === 'personas'}
                  onClick={() => {
                    setActiveModule('personas');
                    setChatHistory([]);
                  }}
                  color="blue"
                >
                  <Library className="w-5 h-5" />
                  <div className="flex flex-col items-start">
                    <span className="text-sm font-medium">AI Models</span>
                    <span className="text-[10px] opacity-50">Neural Personas</span>
                  </div>
                </FuturisticButton>

                <p className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/30 mb-4 mt-6 px-2">Core Modules</p>
                {MODULES.map((m) => (
                  <FuturisticButton 
                    key={`module-btn-${m.id}`}
                    active={activeModule === m.id}
                    onClick={() => {
                      setActiveModule(m.id);
                      setActivePersona(null);
                      setChatHistory([]);
                    }}
                    color={m.color}
                  >
                    {m.id === 'cosmo' && <Brain className="w-5 h-5" />}
                    {m.id === 'orion' && <Gamepad2 className="w-5 h-5" />}
                    {m.id === 'penton' && <GraduationCap className="w-5 h-5" />}
                    {m.id === 'gamma' && <HeartPulse className="w-5 h-5" />}
                    <div className="flex flex-col items-start">
                      <span className="text-sm font-medium">{m.name}</span>
                      <span className="text-[10px] opacity-50">{m.version}</span>
                    </div>
                  </FuturisticButton>
                ))}
              </div>

              <div className="mt-10 space-y-2">
                <div className="flex items-center justify-between px-2 mb-4">
                  <p className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/30">Recent Chats</p>
                  <button 
                    onClick={createNewChat}
                    className="p-1 hover:bg-white/10 rounded-lg transition-colors text-blue-400"
                    title="New Chat"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-1 max-h-[300px] overflow-y-auto custom-scrollbar pr-2">
                  {userChats.slice(0, 5).map(chat => (
                    <button
                      key={`sidebar-chat-${chat.id}`}
                      onClick={() => loadChat(chat)}
                      className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-left transition-all group ${
                        activeChatId === chat.id ? 'bg-blue-600/20 text-blue-400' : 'hover:bg-white/5 text-white/60'
                      }`}
                    >
                      <MessageSquare className="w-4 h-4 opacity-50" />
                      <span className="text-xs font-medium truncate flex-1">{chat.title}</span>
                    </button>
                  ))}
                  {userChats.length > 5 && (
                    <button 
                      onClick={() => setIsAllChatsOpen(true)}
                      className="w-full text-center py-2 text-[10px] font-bold uppercase tracking-widest text-white/30 hover:text-white transition-colors"
                    >
                      Show All Chats
                    </button>
                  )}
                  {userChats.length === 0 && (
                    <p className="text-[10px] text-white/20 italic px-4">No recent chats</p>
                  )}
                </div>
              </div>

              <div className="mt-10 space-y-2">
                <p className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/30 mb-4 px-2">System</p>
                <FuturisticButton 
                  active={activeModule === 'profile'}
                  onClick={() => setActiveModule('profile')}
                  color="blue"
                >
                  <User className="w-5 h-5" />
                  <span className="text-sm font-medium">Profile</span>
                </FuturisticButton>
                {isAdmin && (
                  <FuturisticButton 
                    active={activeModule === 'admin'}
                    onClick={() => setActiveModule('admin')}
                    color="purple"
                  >
                    <ShieldCheck className="w-5 h-5" />
                    <span className="text-sm font-medium">Creator Dashboard</span>
                  </FuturisticButton>
                )}
                <FuturisticButton 
                  active={activeModule === 'payment'}
                  onClick={() => setActiveModule('payment')}
                  color="emerald"
                >
                  <CreditCard className="w-5 h-5" />
                  <span className="text-sm font-medium">Premium Upgrade</span>
                </FuturisticButton>
                <FuturisticButton 
                  active={activeModule === 'manual'}
                  onClick={() => setActiveModule('manual')}
                  color="blue"
                >
                  <BookOpen className="w-5 h-5" />
                  <span className="text-sm font-medium">User Manual</span>
                </FuturisticButton>
              </div>
            </div>

            <div className="mt-auto p-6 border-t border-white/5">
              <div className="flex items-center gap-3 mb-4">
                <img src={profile?.photoURL} className="w-10 h-10 rounded-full border border-white/10" alt="Avatar" referrerPolicy="no-referrer" />
                <div className="flex flex-col">
                  <span className="text-sm font-medium truncate max-w-[120px]">{profile?.displayName}</span>
                  <span className="text-[10px] text-blue-400 flex items-center gap-1">
                    <Zap className="w-3 h-3 fill-current" />
                    {profile?.points} Points
                  </span>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="flex items-center gap-2 text-xs text-white/40 hover:text-rose-400 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Terminate Session
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-6 bg-[#050505]/80 backdrop-blur-md z-40">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Bell className="w-5 h-5 text-white/40 hover:text-white cursor-pointer transition-colors" />
              {notifications.filter(n => !n.read).length > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full" />
              )}
            </div>
            {profile?.isPremium && (
              <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full flex items-center gap-2">
                <Trophy className="w-3 h-3 text-amber-500" />
                <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">Premium</span>
              </div>
            )}
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 relative">
          <div className="absolute inset-0 pointer-events-none z-0 opacity-5 mix-blend-overlay overflow-hidden">
            <img 
              src="https://media.gettyimages.com/id/92893866/photo/space-stars-texture.jpg?s=612x612&w=0&k=20&c=ixEfktRhm0JacTO8yTkU1ExlceBqIZ7PfsHAyWmxG20=" 
              className="w-full h-full object-cover"
              alt="Space Texture"
              referrerPolicy="no-referrer"
            />
          </div>
          <AnimatePresence mode="wait">
            {['cosmo', 'orion', 'penton', 'gamma', 'nova'].includes(activeModule) && (
              <motion.div 
                key={activeModule}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="max-w-4xl mx-auto h-full flex flex-col"
              >
                {activePersona ? (
                  <div className="mb-8 flex items-center gap-6">
                    <img 
                      src={activePersona.imageUrl} 
                      alt={activePersona.name} 
                      className="w-20 h-20 rounded-2xl object-cover border-2 border-white/10"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="text-[10px] font-mono tracking-widest uppercase opacity-50">{activePersona.category}</span>
                        <div className={`h-px w-12 bg-${activePersona.color}-500/50`} />
                      </div>
                      <h1 className="text-3xl font-bold text-white">{activePersona.name}</h1>
                      <p className="text-white/60 text-sm">{activePersona.description}</p>
                    </div>
                  </div>
                ) : (
                  <ModuleHeader module={MODULES.find(m => m.id === activeModule)!} />
                )}
                
                <div className="flex-1 bg-white/5 border border-white/10 rounded-3xl p-6 mb-6 overflow-y-auto custom-scrollbar relative">
                  {activeModule === 'nova' && (
                    <div className="absolute inset-0 pointer-events-none z-0 opacity-20 mix-blend-screen overflow-hidden">
                      <img 
                        src="https://media.gettyimages.com/id/92893866/photo/space-stars-texture.jpg?s=612x612&w=0&k=20&c=ixEfktRhm0JacTO8yTkU1ExlceBqIZ7PfsHAyWmxG20=" 
                        className="w-full h-full object-cover"
                        alt="Nova Background"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}
                  <div className="relative z-10">
                    {chatHistory.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-20">
                        {activeModule === 'nova' ? <Sparkles className="w-16 h-16 mb-4" /> : <Brain className="w-16 h-16 mb-4" />}
                        <p className="text-lg font-medium">
                          {activeModule === 'nova' ? "Describe the image you want to generate" : "Neural connection established. How can I assist you?"}
                        </p>
                        <p className="text-sm">Response time: ~1.2ms</p>
                      </div>
                    ) : (
                      chatHistory.map((msg, i) => (
                        <ChatMessage 
                          key={`chat-msg-${i}-${msg.timestamp || Date.now()}`} 
                          message={msg.parts[0].text} 
                          isUser={msg.role === 'user'} 
                          imageUrl={(msg as any).imageUrl}
                        />
                      ))
                    )}
                    {isLoading && (
                      <div className="flex justify-start mb-4">
                        <div className="bg-white/5 border border-white/10 px-4 py-3 rounded-2xl flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                </div>

                <div className="relative group/input">
                  <div className="flex items-center gap-4 mb-2 px-2">
                    <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5">
                      <Sparkles className="w-3 h-3 text-blue-400" />
                      <span className="text-[10px] font-mono uppercase tracking-wider text-white/40">Enhancement Level</span>
                      <select 
                        value={detailLevel}
                        onChange={(e: any) => setDetailLevel(e.target.value)}
                        className="bg-transparent text-[10px] font-bold text-blue-400 focus:outline-none cursor-pointer"
                      >
                        <option value="simple">Simple</option>
                        <option value="detailed">Detailed</option>
                        <option value="complex">Complex</option>
                      </select>
                    </div>
                    <button 
                      onClick={enhanceText}
                      disabled={isEnhancing || !input.trim()}
                      className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 rounded-lg text-[10px] font-bold text-blue-400 transition-all disabled:opacity-50"
                    >
                      {isEnhancing ? (
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }} className="w-3 h-3 border border-blue-400 border-t-transparent rounded-full" />
                      ) : (
                        <Zap className="w-3 h-3" />
                      )}
                      {isEnhancing ? 'Enhancing...' : 'Enhance Text'}
                    </button>
                  </div>
                  <div className="relative">
                    <textarea 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      placeholder={`Message ${activeModule.toUpperCase()}... (Shift+Enter for new line)`}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 pr-16 focus:outline-none focus:border-blue-500/50 transition-colors min-h-[80px] resize-none custom-scrollbar"
                    />
                    <button 
                      onClick={sendMessage}
                      disabled={isLoading || !input.trim()}
                      className="absolute right-3 bottom-3 p-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:hover:bg-blue-600 rounded-xl transition-colors"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeModule === 'personas' && (
              <motion.div 
                key="personas"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-5xl mx-auto"
              >
                <div className="mb-12">
                  <h2 className="text-4xl font-bold mb-2">Neural Personas</h2>
                  <p className="text-white/50">Engage with specialized AI models and legendary characters.</p>
                </div>

                {/* Category Selection */}
                <div className="flex flex-wrap gap-4 mb-12">
                  {['Professional', 'Historical', 'Fictional'].map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedPersonaCategory(category as any)}
                      className={`px-8 py-4 rounded-2xl font-bold text-sm transition-all border ${
                        selectedPersonaCategory === category 
                          ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20' 
                          : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {category} Models
                    </button>
                  ))}
                </div>

                <motion.div 
                  key={selectedPersonaCategory}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                  {PERSONAS.filter(p => p.category === selectedPersonaCategory).map((persona) => (
                    <motion.div
                      key={`persona-card-${persona.id}`}
                      whileHover={{ y: -5 }}
                      className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden group cursor-pointer"
                      onClick={() => {
                        if (persona.initialQuestions) {
                          setActivePersona(persona);
                          setPersonaSetupData({});
                          setIsPersonaSetupOpen(true);
                        } else {
                          setActivePersona(persona);
                          setActiveModule('cosmo'); // Default to cosmo for chat
                          setChatHistory([]);
                          setPersonaSetupData({});
                        }
                      }}
                    >
                      <div className="h-48 relative overflow-hidden">
                        <img 
                          src={persona.imageUrl} 
                          alt={persona.name} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] to-transparent" />
                        <div className="absolute bottom-4 left-4">
                          <span className={`px-2 py-1 bg-${persona.color}-500/20 text-${persona.color}-400 text-[10px] font-bold rounded-md uppercase border border-${persona.color}-500/30`}>
                            {persona.category}
                          </span>
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold mb-2 group-hover:text-blue-400 transition-colors">{persona.name}</h3>
                        <p className="text-white/50 text-sm mb-4 line-clamp-2">{persona.description}</p>
                        <div className="flex items-center gap-2 text-xs font-bold text-blue-400">
                          Initialize Neural Link <ChevronRight className="w-4 h-4" />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </motion.div>
            )}

            {activeModule === 'manual' && (
              <motion.div 
                key="manual"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto"
              >
                <div className="mb-12">
                  <h2 className="text-4xl font-bold mb-2">User Manual</h2>
                  <p className="text-white/50">Master the Hercules AI Universal Intelligence System.</p>
                </div>

                <div className="space-y-8">
                  <section className="bg-white/5 border border-white/10 rounded-3xl p-8">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
                      <Zap className="w-6 h-6 text-blue-400" />
                      Getting Started
                    </h3>
                    <div className="space-y-4 text-white/70 leading-relaxed">
                      <p>Welcome to Hercules AI. To begin, select a core module from the sidebar or choose a specialized persona from the "AI Models" section.</p>
                      <ul className="list-disc pl-6 space-y-2">
                        <li><strong>Cosmo:</strong> Your general-purpose knowledge assistant.</li>
                        <li><strong>Orion:</strong> Specialized in entertainment, games, and leisure.</li>
                        <li><strong>Penton:</strong> Focused on education, career growth, and academic support.</li>
                        <li><strong>Gamma:</strong> Your health, wellness, and medical information guide.</li>
                      </ul>
                    </div>
                  </section>

                  <section className="bg-white/5 border border-white/10 rounded-3xl p-8">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
                      <Sparkles className="w-6 h-6 text-purple-400" />
                      Neural Personas
                    </h3>
                    <div className="space-y-4 text-white/70 leading-relaxed">
                      <p>Neural Personas allow you to interact with AI that adopts specific professional or fictional identities. This provides a more immersive and tailored experience.</p>
                      <p>Simply click on "AI Models" in the sidebar, select your desired persona, and the system will automatically configure the neural link.</p>
                      <p><strong>Note:</strong> Some professional personas (like Professor Sage or Dr. Helix) will ask for initial context (e.g., your class or symptoms) to provide more accurate assistance.</p>
                    </div>
                  </section>

                  <section className="bg-white/5 border border-white/10 rounded-3xl p-8">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
                      <ShieldCheck className="w-6 h-6 text-emerald-400" />
                      Troubleshooting & FAQ
                    </h3>
                    <div className="space-y-6">
                      <div>
                        <h4 className="font-bold text-white mb-2">Q: Why is the AI not responding?</h4>
                        <p className="text-sm text-white/60">A: Ensure you have a stable internet connection and that your message limits haven't been exceeded. Check the "Profile" section for your current usage.</p>
                      </div>
                      <div>
                        <h4 className="font-bold text-white mb-2">Q: How do I upgrade to Premium?</h4>
                        <p className="text-sm text-white/60">A: Navigate to the "Premium Upgrade" section, select a plan, and follow the payment instructions. Our administrators will approve your request shortly after verification.</p>
                      </div>
                      <div>
                        <h4 className="font-bold text-white mb-2">Q: Can I reset my message limits?</h4>
                        <p className="text-sm text-white/60">A: Premium users have access to manual limit resets (Monthly or Yearly) via their profile page.</p>
                      </div>
                    </div>
                  </section>
                </div>
              </motion.div>
            )}

            {/* Persona Setup Modal */}
            {/* Modals */}
      <AllChatsModal 
        isOpen={isAllChatsOpen}
        onClose={() => setIsAllChatsOpen(false)}
        chats={userChats}
        onLoad={loadChat}
        onRename={renameChat}
        onDelete={deleteChat}
      />

      <AnimatePresence>
              {isPersonaSetupOpen && activePersona && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 bg-black/80 backdrop-blur-sm"
                    onClick={() => setIsPersonaSetupOpen(false)}
                  />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: 20 }}
                    className="relative w-full max-w-md bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 shadow-2xl overflow-hidden"
                  >
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500" />
                    
                    <div className="flex items-center gap-4 mb-8">
                      <div className={`p-3 bg-${activePersona.color}-500/20 rounded-2xl`}>
                        {activePersona.id === 'teacher' && <GraduationCap className={`w-6 h-6 text-${activePersona.color}-400`} />}
                        {activePersona.id === 'doctor' && <HeartPulse className={`w-6 h-6 text-${activePersona.color}-400`} />}
                        {activePersona.id === 'engineer' && <ShieldCheck className={`w-6 h-6 text-${activePersona.color}-400`} />}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">Neural Link Setup</h3>
                        <p className="text-white/50 text-xs">Configuring {activePersona.name}</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      {activePersona.initialQuestions?.map((q) => (
                        <div key={`persona-q-${q.id}`}>
                          <label className="block text-[10px] font-mono uppercase tracking-widest text-white/40 mb-2">{q.label}</label>
                          {q.type === 'select' ? (
                            <select 
                              value={personaSetupData[q.id] || ''}
                              onChange={(e) => setPersonaSetupData(prev => ({ ...prev, [q.id]: e.target.value }))}
                              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500/50 transition-colors text-sm"
                            >
                              <option value="" disabled>{q.placeholder}</option>
                              {q.options?.map(opt => (
                                <option key={`persona-opt-${opt}`} value={opt} className="bg-[#0a0a0a]">{opt}</option>
                              ))}
                            </select>
                          ) : (
                            <input 
                              type="text"
                              value={personaSetupData[q.id] || ''}
                              onChange={(e) => setPersonaSetupData(prev => ({ ...prev, [q.id]: e.target.value }))}
                              placeholder={q.placeholder}
                              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500/50 transition-colors text-sm"
                            />
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="mt-10 flex gap-3">
                      <button 
                        onClick={() => setIsPersonaSetupOpen(false)}
                        className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-bold transition-all"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={() => {
                          setIsPersonaSetupOpen(false);
                          setActiveModule('cosmo');
                          setChatHistory([]);
                        }}
                        className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-bold transition-all shadow-lg shadow-blue-600/20"
                      >
                        Initialize Link
                      </button>
                    </div>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>
            {activeModule === 'profile' && (
              <motion.div 
                key="profile"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-2xl mx-auto"
              >
                <h2 className="text-3xl font-bold mb-8">User Profile</h2>
                <div className="bg-white/5 border border-white/10 rounded-3xl p-8 relative overflow-hidden">
                  <div className="flex items-center gap-6 mb-10">
                    <img src={profile?.photoURL} className="w-24 h-24 rounded-3xl border-2 border-blue-500/30" alt="Profile" referrerPolicy="no-referrer" />
                    <div>
                      <h3 className="text-2xl font-bold">{profile?.displayName}</h3>
                      <p className="text-white/40">{profile?.email}</p>
                      <div className="flex flex-col gap-2 mt-2">
                        {profile?.isPremium && (
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-500 text-[10px] font-bold rounded-md uppercase">{profile.subscriptionType} Premium</span>
                            <span className="text-[10px] font-bold text-amber-500/60 italic">Premium User</span>
                          </div>
                        )}
                        <span className="w-fit px-2 py-0.5 bg-blue-500/20 text-blue-400 text-[10px] font-bold rounded-md uppercase">Level {Math.floor((profile?.points || 0) / 100) + 1}</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mb-1">Total Points</p>
                      <p className="text-2xl font-bold text-blue-400">{profile?.points}</p>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mb-1">Badges Earned</p>
                      <p className="text-2xl font-bold text-purple-400">{profile?.badges.length}</p>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
                      <p className="text-[10px] uppercase tracking-wider text-white/30 mb-1">Message Usage</p>
                      <p className="text-2xl font-bold text-emerald-400">
                        {(profile?.messageCounts?.cosmo || 0) + (profile?.messageCounts?.orion || 0) + (profile?.messageCounts?.penton || 0) + (profile?.messageCounts?.gamma || 0) + (profile?.messageCounts?.nova || 0)}
                        <span className="text-sm text-white/30 ml-1">/ {systemSettings.limits[profile?.isPremium ? (profile.subscriptionType || 'monthly') : 'free'].cosmo}</span>
                      </p>
                    </div>
                  </div>

                  {/* Creator Label */}
                  {profile?.email === CREATOR_EMAIL && (
                    <div className="mt-12 pt-8 border-t border-white/5 flex flex-col items-center">
                      <div className="px-4 py-1 bg-blue-600/20 text-blue-400 text-xs font-bold rounded-full border border-blue-500/30 uppercase tracking-widest animate-pulse">
                        Creator
                      </div>
                      <p className="text-[10px] text-white/20 mt-2 italic">Unlimited Access Granted</p>
                    </div>
                  )}

                  {/* Limit Resets */}
                  {(profile?.subscriptionType === 'monthly' || profile?.subscriptionType === 'yearly') && (
                    <div className="mb-8 space-y-3">
                      <h4 className="text-sm font-bold uppercase tracking-widest text-white/30 mb-4">Subscription Features</h4>
                      <div className="flex gap-3">
                        <button 
                          onClick={() => resetLimits('monthly')}
                          className="flex-1 py-3 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                        >
                          <Zap className="w-4 h-4" />
                          Monthly Limit Reset
                        </button>
                        {profile?.subscriptionType === 'yearly' && (
                          <button 
                            onClick={() => resetLimits('yearly')}
                            className="flex-1 py-3 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                          >
                            <Sparkles className="w-4 h-4" />
                            Yearly Limit Reset
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  <h4 className="text-sm font-bold uppercase tracking-widest text-white/30 mb-4">Achievements</h4>
                  <div className="flex flex-wrap gap-3 mb-10">
                    {profile?.badges.length === 0 ? (
                      <p className="text-sm text-white/20 italic">No badges earned yet. Interact with AI modules to unlock them.</p>
                    ) : (
                      profile?.badges.map((b, i) => (
                        <div key={`badge-${b}-${i}`} className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center gap-2">
                          <Trophy className="w-4 h-4 text-amber-500" />
                          <span className="text-sm">{b}</span>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Creator Label */}
                  {isAdmin && (
                    <div className="pt-6 border-t border-white/5 text-center">
                      <span className="text-4xl font-black tracking-tighter opacity-10 select-none uppercase">Creator</span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {activeModule === 'payment' && (
              <motion.div 
                key="payment"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto text-center"
              >
                {!selectedPlan ? (
                  <>
                    <div className="mb-10">
                      <div className="w-20 h-20 bg-amber-500/10 border border-amber-500/30 rounded-3xl flex items-center justify-center mx-auto mb-6">
                        <CreditCard className="w-10 h-10 text-amber-500" />
                      </div>
                      <h2 className="text-4xl font-bold mb-4">Choose Your Plan</h2>
                      <p className="text-white/50">Unlock exclusive features, higher limits, and priority AI processing.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                      {/* Free Plan */}
                      <div className="bg-white/5 border border-white/10 rounded-3xl p-8 flex flex-col items-center hover:border-white/20 transition-all group">
                        <h3 className="text-xl font-bold mb-2">Free Plan</h3>
                        <div className="flex items-baseline gap-1 mb-6">
                          <span className="text-4xl font-bold">₹0</span>
                          <span className="text-white/40 text-sm">/forever</span>
                        </div>
                        <ul className="text-left space-y-3 mb-8 text-sm text-white/60 w-full">
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-white/40" /> Basic AI Access</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-white/40" /> 6 Messages / Day</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-white/40" /> Standard Support</li>
                        </ul>
                        <div className="w-full py-4 bg-white/10 rounded-2xl font-bold text-white/40 text-center">
                          {(!profile?.isPremium && !isAdmin) ? 'Current Plan' : 'Standard Access'}
                        </div>
                      </div>

                      {/* Monthly Plan */}
                      <div className="bg-white/5 border border-white/10 rounded-3xl p-8 flex flex-col items-center hover:border-blue-500/30 transition-all group">
                        <h3 className="text-xl font-bold mb-2">Monthly Premium</h3>
                        <div className="flex items-baseline gap-1 mb-6">
                          <span className="text-4xl font-bold">₹399</span>
                          <span className="text-white/40 text-sm">/month</span>
                        </div>
                        <ul className="text-left space-y-3 mb-8 text-sm text-white/60 w-full">
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> 12 Messages / Day</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Monthly Limit Reset</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Priority Processing</li>
                        </ul>
                        <button 
                          onClick={() => setSelectedPlan('monthly')}
                          className="w-full py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-bold transition-all"
                        >
                          Select Monthly
                        </button>
                      </div>

                      {/* Yearly Plan */}
                      <div className="bg-white/5 border border-amber-500/20 rounded-3xl p-8 flex flex-col items-center relative overflow-hidden hover:border-amber-500/50 transition-all group">
                        <div className="absolute top-4 right-4 px-3 py-1 bg-amber-500 text-black text-[10px] font-bold rounded-full uppercase tracking-wider">Best Value</div>
                        <h3 className="text-xl font-bold mb-2">Yearly Premium</h3>
                        <div className="flex items-baseline gap-1 mb-2">
                          <span className="text-4xl font-bold">₹2999</span>
                          <span className="text-white/40 text-sm">/year</span>
                        </div>
                        <p className="text-emerald-400 text-xs font-bold mb-6">Save ₹589 compared to monthly plan</p>
                        <ul className="text-left space-y-3 mb-8 text-sm text-white/60 w-full">
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> 30 Messages / Day</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Monthly & Yearly Limit Reset</li>
                          <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Priority Processing</li>
                        </ul>
                        <button 
                          onClick={() => setSelectedPlan('yearly')}
                          className="w-full py-4 bg-amber-500 text-black hover:bg-amber-400 rounded-2xl font-bold transition-all"
                        >
                          Select Yearly
                        </button>
                      </div>
                    </div>
                  </>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="max-w-md mx-auto bg-white/5 border border-white/10 rounded-3xl p-8"
                  >
                    <button 
                      onClick={() => setSelectedPlan(null)}
                      className="mb-6 text-xs text-white/40 hover:text-white flex items-center gap-2"
                    >
                      <ChevronRight className="w-4 h-4 rotate-180" />
                      Back to Plans
                    </button>
                    <div className="w-16 h-16 bg-blue-500/10 border border-blue-500/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <CreditCard className="w-8 h-8 text-blue-400" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2">Complete Payment</h3>
                    <p className="text-white/50 mb-8 text-sm">You've selected the <span className="text-blue-400 font-bold uppercase">{selectedPlan}</span> plan.</p>
                    
                    <div className="space-y-6 text-left mb-8">
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                        <p className="text-[10px] uppercase tracking-wider text-white/30 mb-1">Amount to Pay</p>
                        <p className="text-3xl font-bold text-white">₹{selectedPlan === 'monthly' ? '399' : '2999'}</p>
                      </div>
                      
                      <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                        <p className="text-[10px] uppercase tracking-wider text-white/30 mb-1">Pay to UPI ID</p>
                        <p className="text-xl font-mono font-bold text-blue-400">{UPI_ID}</p>
                      </div>
                    </div>

                    <div className="text-left space-y-4 mb-8">
                      <h4 className="text-sm font-bold text-white/80">Next Steps:</h4>
                      <ol className="text-xs text-white/40 space-y-2 list-decimal pl-4">
                        <li>Pay the amount above using any UPI app (GPay, PhonePe, etc.).</li>
                        <li>Take a screenshot of the successful transaction.</li>
                        <li>Send the screenshot to <span className="text-blue-400 font-bold">{CREATOR_EMAIL}</span>.</li>
                        <li>Your premium status will be activated within 24 hours of verification.</li>
                      </ol>
                    </div>

                    <button 
                      onClick={async () => {
                        if (!user) return;
                        await addDoc(collection(db, 'payments'), {
                          userId: user.uid,
                          userEmail: user.email,
                          status: 'pending',
                          planType: selectedPlan,
                          upiId: UPI_ID,
                          timestamp: new Date().toISOString()
                        });
                        alert(`${selectedPlan?.toUpperCase()} Payment request logged. Please send the screenshot to ${CREATOR_EMAIL} now.`);
                        setSelectedPlan(null);
                        setActiveModule('cosmo');
                      }}
                      className="w-full py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-bold transition-all"
                    >
                      I've Made the Payment
                    </button>
                    <p className="text-[10px] text-white/20 mt-4 italic text-center">Hercules AI Premium - Powered by Atharv Sharma</p>
                  </motion.div>
                )}

                {/* Plan Limits Overview */}
                <div className="mt-16 pt-12 border-t border-white/5">
                  <h3 className="text-xl font-bold mb-8 uppercase tracking-widest text-white/30">Plan Limits Overview</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {['free', 'monthly', 'yearly'].map((plan) => (
                      <div key={plan} className={`p-6 rounded-3xl border ${profile?.subscriptionType === plan || (plan === 'free' && !profile?.subscriptionType) ? 'bg-blue-500/5 border-blue-500/20' : 'bg-white/5 border-white/5'}`}>
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-xs font-bold uppercase tracking-wider text-white/60">{plan} Plan</span>
                          {((profile?.subscriptionType === plan) || (plan === 'free' && (!profile?.subscriptionType || profile?.subscriptionType === 'none'))) && (
                            <span className="px-2 py-0.5 bg-blue-500 text-[8px] font-bold rounded uppercase">Active</span>
                          )}
                        </div>
                        <div className="space-y-3">
                          {Object.entries(systemSettings.limits[plan as keyof typeof systemSettings.limits]).map(([module, limit]) => (
                            <div key={module} className="flex justify-between items-center">
                              <span className="text-[10px] text-white/30 uppercase">{module}</span>
                              <span className="text-sm font-mono font-bold text-white/80">{limit}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="mt-8 text-[10px] text-white/20 italic">Limits are configured and saved by the creator for optimal performance.</p>
                </div>
              </motion.div>
            )}

            {activeModule === 'admin' && isAdmin && (
              <AdminDashboard />
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Atmospheric Glows */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] bg-blue-600/5 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[60%] h-[60%] bg-purple-600/5 blur-[150px] rounded-full" />
      </div>
    </div>
  );
}

function AdminDashboard() {
  const [payments, setPayments] = useState<PaymentRequest[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [limits, setLimits] = useState<SystemSettings['limits']>({
    free: { cosmo: 6, orion: 6, penton: 6, gamma: 6, nova: 6 },
    monthly: { cosmo: 12, orion: 12, penton: 12, gamma: 12, nova: 12 },
    yearly: { cosmo: 30, orion: 30, penton: 30, gamma: 30, nova: 30 }
  });
  const [activePlanTab, setActivePlanTab] = useState<'free' | 'monthly' | 'yearly'>('free');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [allChats, setAllChats] = useState<Chat[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'chats' | 'settings'>('overview');
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'payments'), orderBy('timestamp', 'desc'));
    const unsubscribePayments = onSnapshot(q, (snapshot) => {
      setPayments(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as PaymentRequest)));
    }, (error) => console.error("Admin payments listener error:", error));

    const unsubscribeUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
    }, (error) => console.error("Admin users listener error:", error));

    const unsubscribeSettings = onSnapshot(doc(db, 'settings', 'global'), (doc) => {
      if (doc.exists()) {
        setLimits(doc.data().limits);
      }
    }, (error) => console.error("Admin settings listener error:", error));

    const unsubscribeChats = onSnapshot(query(collection(db, 'chats'), orderBy('updatedAt', 'desc')), (snapshot) => {
      setAllChats(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Chat)));
    }, (error) => console.error("Admin chats listener error:", error));

    return () => {
      unsubscribePayments();
      unsubscribeUsers();
      unsubscribeSettings();
      unsubscribeChats();
    };
  }, []);

  const totalSignIns = users.length;
  const totalPremiumUsers = users.filter(u => u.isPremium).length;
  const totalMessages = users.reduce((acc, u) => {
    const counts = u.messageCounts || { cosmo: 0, orion: 0, penton: 0, gamma: 0, nova: 0 };
    const sum = (counts.cosmo || 0) + (counts.orion || 0) + (counts.penton || 0) + (counts.gamma || 0) + (counts.nova || 0);
    return acc + sum;
  }, 0);

  const approvePayment = async (payment: PaymentRequest) => {
    if (!payment.id) return;
    await updateDoc(doc(db, 'payments', payment.id), { status: 'approved' });
    
    const days = payment.planType === 'monthly' ? 30 : 365;
    grantPremium(payment.userId, days, payment.planType);
  };

  const grantPremium = async (userId: string, days: number, planType: 'monthly' | 'yearly' | 'none' = 'monthly') => {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + days);
    
    await updateDoc(doc(db, 'users', userId), { 
      isPremium: true,
      subscriptionType: planType,
      premiumUntil: expiry.toISOString()
    });

    await addDoc(collection(db, 'notifications'), {
      userId: userId,
      title: 'Premium Activated',
      message: `Your Hercules AI ${planType} Premium access has been activated for ${days} days!`,
      type: 'success',
      read: false,
      timestamp: new Date().toISOString()
    });
  };

  const toggleBlock = async (userId: string, currentStatus: boolean) => {
    await updateDoc(doc(db, 'users', userId), { isBlocked: !currentStatus });
  };

  const deleteUser = async (userId: string) => {
    if (window.confirm("Are you sure you want to permanently delete this user and all their data? This action is irreversible.")) {
      await deleteDoc(doc(db, 'users', userId));
      alert("User deleted successfully.");
    }
  };

  const updateLimits = async () => {
    await setDoc(doc(db, 'settings', 'global'), { limits });
    alert("Limits updated successfully.");
  };

  const addUserManually = async () => {
    if (!newUserEmail.trim()) return;
    const uid = `manual_${Math.random().toString(36).substr(2, 9)}`;
    await setDoc(doc(db, 'users', uid), {
      uid,
      email: newUserEmail,
      displayName: 'New User',
      photoURL: `https://picsum.photos/seed/${uid}/200`,
      isPremium: false,
      points: 0,
      badges: [],
      createdAt: new Date().toISOString()
    });
    setNewUserEmail('');
    alert("User added to system overview.");
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-6xl mx-auto space-y-12 pb-20"
    >
      <div className="flex justify-between items-center">
        <h2 className="text-4xl font-black tracking-tighter flex items-center gap-4">
          <ShieldCheck className="w-10 h-10 text-purple-500" />
          CREATOR DASHBOARD
        </h2>
        <div className="flex p-1 bg-white/5 rounded-2xl border border-white/10">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === 'overview' ? 'bg-blue-600 text-white' : 'text-white/40 hover:text-white'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('chats')}
            className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === 'chats' ? 'bg-blue-600 text-white' : 'text-white/40 hover:text-white'}`}
          >
            User Chats
          </button>
        </div>
      </div>

      {activeTab === 'overview' ? (
        <>
          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/5 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
            <User className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-white/40">Total Sign-ins</p>
            <p className="text-2xl font-bold">{totalSignIns}</p>
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center">
            <Send className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-white/40">Total Messages</p>
            <p className="text-2xl font-bold">{totalMessages}</p>
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-white/40">Premium Users</p>
            <p className="text-2xl font-bold">{totalPremiumUsers}</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Limits Section */}
        <div className="lg:col-span-1 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-400" />
            System Limits
          </h3>
          <div className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-6">
            <div className="flex p-1 bg-white/5 rounded-xl">
              {(['free', 'monthly', 'yearly'] as const).map((plan) => (
                <button
                  key={plan}
                  onClick={() => setActivePlanTab(plan)}
                  className={`flex-1 py-2 text-[10px] font-bold uppercase rounded-lg transition-all ${
                    activePlanTab === plan ? 'bg-blue-600 text-white' : 'text-white/40 hover:text-white'
                  }`}
                >
                  {plan}
                </button>
              ))}
            </div>
            <div className="space-y-4">
              {Object.entries(limits[activePlanTab]).map(([module, limit]) => (
                <div key={`admin-limit-${activePlanTab}-${module}`} className="flex items-center justify-between">
                  <span className="text-sm uppercase text-white/50">{module} Limit</span>
                  <input 
                    type="number" 
                    value={limit}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setLimits({
                        ...limits, 
                        [activePlanTab]: {
                          ...limits[activePlanTab],
                          [module]: val
                        }
                      });
                    }}
                    className="w-20 bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-center text-sm"
                  />
                </div>
              ))}
            </div>
            <button 
              onClick={updateLimits}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-xs font-bold transition-colors mt-4"
            >
              Update {activePlanTab.toUpperCase()} Limits
            </button>
          </div>
        </div>

        {/* Payments Section */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-500" />
            Pending Verifications
          </h3>
          <div className="space-y-4">
            {payments.filter(p => p.status === 'pending').length === 0 ? (
              <p className="text-white/30 italic">No pending payment requests.</p>
            ) : (
              payments.filter(p => p.status === 'pending').map(p => (
                <div key={`admin-pending-pay-${p.id}`} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium">{p.userEmail}</p>
                    <p className="text-[10px] text-white/40">{new Date(p.timestamp).toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => approvePayment(p)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-bold transition-colors flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Approve {p.planType === 'monthly' ? 'Monthly' : 'Yearly'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Users Overview */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <User className="w-5 h-5 text-blue-500" />
          User Management Overview
        </h3>
        <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-white/40 text-[10px] uppercase tracking-widest">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Total Usage</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {users.map(u => (
                <tr key={`admin-user-${u.uid}`} className={`hover:bg-white/5 transition-colors ${u.isBlocked ? 'opacity-50' : ''}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={u.photoURL} className="w-8 h-8 rounded-full" alt="" referrerPolicy="no-referrer" />
                      <div className="flex flex-col">
                        <span className="font-medium">{u.displayName}</span>
                        <span className="text-[10px] text-white/30">{u.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      {u.email === CREATOR_EMAIL && <span className="text-blue-400 font-bold text-[10px] uppercase">Creator</span>}
                      {u.isPremium ? (
                        <div className="flex flex-col">
                          <span className="text-amber-500 font-bold text-[10px] uppercase">Premium</span>
                          <span className="text-white/30 text-[8px] uppercase">
                            Until {u.premiumUntil ? new Date(u.premiumUntil).toLocaleDateString() : 'Lifetime'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-white/30 text-[10px] uppercase">Free Plan</span>
                      )}
                      {u.isBlocked && <span className="text-rose-500 font-bold text-[10px] uppercase">Blocked</span>}
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-[10px]">
                    {(u.messageCounts?.cosmo || 0) + (u.messageCounts?.orion || 0) + (u.messageCounts?.penton || 0) + (u.messageCounts?.gamma || 0) + (u.messageCounts?.nova || 0)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => toggleBlock(u.uid, !!u.isBlocked)}
                        className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-colors ${
                          u.isBlocked ? 'bg-emerald-600/20 text-emerald-500 hover:bg-emerald-600/30' : 'bg-rose-600/20 text-rose-500 hover:bg-rose-600/30'
                        }`}
                      >
                        {u.isBlocked ? 'Unblock' : 'Block'}
                      </button>
                      <button 
                        onClick={() => deleteUser(u.uid)}
                        className="px-3 py-1 bg-white/5 hover:bg-rose-600/20 text-white/40 hover:text-rose-500 rounded-lg text-[10px] font-bold transition-all"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Chat List */}
          <div className="lg:col-span-1 space-y-4">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-6">
              <MessageSquare className="w-5 h-5 text-blue-500" />
              All Conversations
            </h3>
            <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar pr-2">
              {allChats.map(chat => (
                <button
                  key={`admin-chat-list-${chat.id}`}
                  onClick={() => setSelectedChat(chat)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all ${
                    selectedChat?.id === chat.id 
                      ? 'bg-blue-600/20 border-blue-500/50' 
                      : 'bg-white/5 border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">{chat.moduleId}</span>
                    <span className="text-[10px] text-white/30">{new Date(chat.updatedAt).toLocaleDateString()}</span>
                  </div>
                  <h4 className="text-sm font-medium truncate mb-1">{chat.title}</h4>
                  <p className="text-[10px] text-white/40 truncate">{chat.userEmail}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Chat Preview */}
          <div className="lg:col-span-2">
            {selectedChat ? (
              <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden flex flex-col h-[700px]">
                <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold">{selectedChat.title}</h3>
                    <p className="text-[10px] text-white/40 uppercase tracking-widest">User: {selectedChat.userEmail}</p>
                  </div>
                  <div className="px-3 py-1 bg-blue-600/20 text-blue-400 text-[10px] font-bold rounded-full border border-blue-500/30">
                    {selectedChat.moduleId.toUpperCase()}
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
                  {selectedChat.messages.map((m, i) => (
                    <div key={`admin-msg-${selectedChat.id}-${i}`} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm ${
                        m.role === 'user' 
                          ? 'bg-blue-600/20 border border-blue-500/30 text-blue-50' 
                          : 'bg-white/5 border border-white/10 text-white/90'
                      }`}>
                        <p className="whitespace-pre-wrap">{m.parts[0].text}</p>
                        <p className="text-[8px] opacity-30 mt-1 text-right">{new Date(m.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-[700px] border border-dashed border-white/10 rounded-3xl flex flex-col items-center justify-center text-white/20">
                <MessageSquare className="w-12 h-12 mb-4 opacity-10" />
                <p>Select a conversation to monitor</p>
              </div>
            )}
          </div>
        </div>
      )}
    </motion.div>
  );
}

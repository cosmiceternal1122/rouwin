import "dotenv/config";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Groq from "groq-sdk";
import cors from "cors";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());

  const groq = new Groq({
    apiKey: process.env.GROQ_API_KEY || "",
  });

  // Groq Proxy Endpoint
  app.post("/api/ai/groq", async (req, res) => {
    try {
      if (!process.env.GROQ_API_KEY) {
        return res.status(401).json({ error: "GROQ_API_KEY is missing. Please set it in the environment variables." });
      }

      const { messages, systemInstruction } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Invalid messages format." });
      }

      const completion = await groq.chat.completions.create({
        messages: [
          { role: "system", content: systemInstruction },
          ...messages
        ],
        model: "llama-3.3-70b-versatile",
      });

      res.json({ text: completion.choices[0]?.message?.content || "" });
    } catch (error: any) {
      console.error("Groq Error:", error);
      res.status(error.status || 500).json({ 
        error: error.message || "An unexpected error occurred with the AI service.",
        details: error.response?.data || null
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
